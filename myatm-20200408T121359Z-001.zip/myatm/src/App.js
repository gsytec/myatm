import React from 'react';
import MyAtm from './atm' ;

function App() {
  return (
    <MyAtm/>
  );
}

export default App;
