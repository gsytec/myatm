import React, { Component } from 'react';


class Note extends Component {

  constructor(props) {
    super(props)

    this.state = {
      amount: "",
      currency: [0,0,0,0,0,0,0,0,0,0],
      noteCounter: [2000, 500, 200, 100, 50, 20, 10, 5, 2, 1],
      allNotes :0
    }
    this.NoteCalculator = this.NoteCalculator.bind(this)
  }

  NoteCalculator() {

    var amount = this.state.amount

    var currency = [2000, 500, 200, 100, 50, 20, 10, 5, 2, 1];
    var noteAdder = [];
    var total =0

    for (let i = 0; i < currency.length; i++) {
      noteAdder[i] = Math.floor(amount / currency[i]);
      amount = amount - noteAdder[i] * currency[i];
    }

    for (let i = 0; i < noteAdder.length; i++){
      total =  total +noteAdder[i]
    }


    this.setState({
      currency: noteAdder,
      allNotes:total
    })


  }



  render() {
    return (
      <div>       


        <div>
         ATM Money Dispensor
        </div>

        <div>

          <div>
            <div>
              <h5>WELCOME TO MY ATM APP </h5>

              <div>
                <h6>Enter Amount</h6>
                <input type="number" placeholder="0" onChange={(event) => { this.setState({ amount: event.target.value }) }} value={this.state.amount} />

                <button type="button" onClick={this.NoteCalculator}>Get Money</button>

              </div>
            </div>

          </div>

          <div  align='right'>

            <h7 >You will get the following amount</h7>

            <div>

              <table>

              <caption> <h7> Total notes Dispensed : {this.state.totalnotes} </h7></caption>
                <tbody>

                  <tr>
                    
                    <td>{this.state.currency[9]} notes of RS. {this.state.noteCounter[9]}</td>
                    <td>{this.state.currency[8]} notes of RS. {this.state.noteCounter[8]}</td>
                    
                  </tr>
                  <tr>
                    <td>{this.state.currency[7]} notes of RS. {this.state.noteCounter[7]}</td>
                    <td>{this.state.currency[6]} notes of RS. {this.state.noteCounter[6]}</td>
                  </tr>
                  <tr>
                    <td>{this.state.currency[5]} notes of RS. {this.state.noteCounter[5]}</td>
                    <td>{this.state.currency[4]} notes of RS. {this.state.noteCounter[4]}</td>
                  </tr>
                  <tr>
                    <td>{this.state.currency[3]} notes of RS. {this.state.noteCounter[3]}</td>
                    <td>{this.state.currency[2]} notes of RS. {this.state.noteCounter[2]}</td>
                  </tr>
                  <tr>
                    <td>{this.state.currency[1]} note of RS. {this.state.noteCounter[1]}</td>
                    <td>{this.state.currency[0]} notes of Rs {this.state.noteCounter[0]}</td>
                  </tr>
                </tbody>
              </table>

            </div>

          </div>

        </div>





      </div>
    );
  }
}

export default Note;
